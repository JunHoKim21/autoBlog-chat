@echo off
chcp 65001 > nul
echo ======================================================
echo Antigravity Blogger Publisher 스킬 자동 설치를 시작합니다.
echo ======================================================
echo.

echo [1/2] 필수 Python 라이브러리 설치 확인 중...
pip install google-api-python-client google-auth-oauthlib markdown
if %errorlevel% neq 0 (
    echo [경고] Python 또는 pip가 설치되어 있지 않거나 경로에 없습니다.
    echo Python을 설치하신 후 다시 실행해주세요.
    pause
    exit /b
)

echo.
echo [2/2] Antigravity 글로벌 스킬 디렉터리로 복사 중...
set TARGET_DIR=%USERPROFILE%\.gemini\config\skills\blogger-publisher
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

xcopy /E /I /Y "%~dp0blogger-publisher" "%TARGET_DIR%"

echo.
echo ======================================================
echo 설치가 성공적으로 완료되었습니다!
echo 구글 로그인 토큰 및 2번 블로그 설정이 모두 포함되어 있어
echo 추가 로그인 없이 바로 동작합니다.
echo.
echo 이제 다른 컴퓨터의 Antigravity에서도
echo "이 내용 블로그에 올려줘"라고 말씀하시면 바로 발행됩니다!
echo ======================================================
echo.
pause
